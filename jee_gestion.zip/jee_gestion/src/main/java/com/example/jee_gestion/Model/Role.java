package com.example.jee_gestion.Model;

public enum Role {
    ADMINISTRATEUR,
    ENSEIGNANT,
    ETUDIANT
}